# Goldpari Over & Under 7.5

A simple Android timer utility. It does not predict outcomes or guarantee winnings.

## What it does
- Uses Nigeria time (`Africa/Lagos`) as the master clock.
- Shows Cameroon time; both are UTC+1.
- You enter the signal time as HH:MM:SS.
- You choose the wait time from 1–60 seconds.
- The app waits the selected number of seconds and then triggers:
  - high-priority Android notification
  - vibration
  - text-to-speech: “O boy! Place bet now ooh! Place bet now! No dulling!”
- Includes a TEST ALERT button.
- Re-schedules the timer after reboot when a future timer is stored.

## Build with GitHub
1. Create a new GitHub repository.
2. Upload all files in this project.
3. Commit to `main`.
4. Open the repository's **Actions** tab.
5. Select **Build Goldpari APK**.
6. Tap **Run workflow** if it did not start automatically.
7. When it finishes, open the workflow run and download the artifact:
   `Goldpari-Over-Under-7.5-APK`
8. Extract it and install `app-debug.apk` on Android.

## Important Android permissions
The app uses exact alarms because the timer is intended to fire at a precise user-selected time. Android may show an “Alarms & reminders” access screen on some versions/devices.

Notifications must also be allowed on Android 13+.

## Note
The voice is configured to prefer a Nigerian English (`en-NG`) voice and, when the phone exposes one, a voice whose name indicates male. It also lowers pitch slightly for a stronger male-style delivery. Android TTS does not standardize voice gender, so the exact voice still depends on the TTS engine/voices installed on the phone.
