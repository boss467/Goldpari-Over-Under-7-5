package com.goldpari.overunder75

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val target = context.getSharedPreferences("timer", Context.MODE_PRIVATE)
            .getLong("target", 0L)
        if (target > System.currentTimeMillis()) {
            SignalReceiver.schedule(context, target)
        }
    }
}
