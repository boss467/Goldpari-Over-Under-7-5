package com.goldpari.overunder75

import android.app.*
import android.content.*
import android.os.*
import android.provider.Settings
import android.net.Uri
import android.speech.tts.TextToSpeech
import java.util.*

class SignalReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        fire(context, false)
    }

    companion object {
        private const val REQ = 7543

        fun schedule(context: Context, triggerAtMs: Long) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(
                context, REQ,
                Intent(context, SignalReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                try {
                    val i = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:${context.packageName}"))
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(i)
                } catch (_: Exception) {}
                return
            }
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
        }

        fun cancel(context: Context) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(
                context, REQ,
                Intent(context, SignalReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.cancel(pi)
        }

        fun fire(context: Context, test: Boolean) {
            NotificationHelper.notify(context, if (test) "🧪 TEST — O BOY! PLACE BET NOW OOH! 😂"
                else "🔔 O BOY! PLACE BET NOW OOH! 😂")

            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) {
                vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 250, 150, 250, 150, 500), -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(1100)
            }

            val tts = TextToSpeech(context.applicationContext) { result ->
                if (result == TextToSpeech.SUCCESS) {
                    val engine = tts
                    val preferred = Locale("en", "NG")

                    // Prefer Nigerian English when the phone's TTS engine provides it.
                    // Then prefer a voice whose name suggests a male voice. Voice gender
                    // metadata is not standardized, so the final voice depends on the
                    // TTS engine installed on the phone.
                    val voices = engine.voices ?: emptySet()
                    val ngVoice = voices
                        .filter { it.locale.language == "en" && it.locale.country.equals("NG", true) }
                        .sortedBy { if (it.name.contains("male", true)) 0 else 1 }
                        .firstOrNull()

                    if (ngVoice != null) {
                        engine.voice = ngVoice
                    } else {
                        engine.language = preferred
                        val englishVoice = voices
                            .filter { it.locale.language == "en" }
                            .sortedBy { if (it.name.contains("male", true)) 0 else 1 }
                            .firstOrNull()
                        if (englishVoice != null) engine.voice = englishVoice
                    }

                    engine.setSpeechRate(0.90f)
                    engine.setPitch(0.82f)
                    engine.speak(
                        "O boy! Place bet now ooh! Place bet now! No dulling!",
                        TextToSpeech.QUEUE_FLUSH, null, "goldpari-alert"
                    )
                }
            }
        }
    }
}
