package com.goldpari.overunder75

import android.app.*
import android.content.*
import android.graphics.Color
import android.os.*
import android.provider.Settings
import android.text.InputType
import android.view.*
import android.widget.*
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : Activity() {
    private val zone = ZoneId.of("Africa/Lagos")
    private lateinit var clockText: TextView
    private lateinit var statusText: TextView
    private lateinit var timeInput: EditText
    private lateinit var secondsInput: EditText
    private lateinit var countdownText: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("timer", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationHelper.createChannel(this)
        requestNotifications()
        buildUi()
        tick()
    }

    private fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 10)
        }
    }

    private fun buildUi() {
        val bg = Color.rgb(11,15,13)
        val green = Color.rgb(34,197,94)
        val white = Color.WHITE
        val muted = Color.rgb(167,176,170)
        val orange = Color.rgb(245,158,11)

        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 30, 28, 30)
            setBackgroundColor(bg)
        }

        fun tv(text: String, size: Float, color: Int = white, bold: Boolean = false): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(color)
                if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(0, 8, 0, 8)
            }

        box.addView(tv("🎲  GOLDPARI", 26f, green, true))
        box.addView(tv("OVER & UNDER 7.5", 22f, white, true))
        box.addView(tv("NO DULLING MODE 😂", 14f, orange, true))
        box.addView(tv("Nigeria 🇳🇬 is the master clock • Cameroon 🇨🇲 matches it", 14f, muted))

        clockText = tv("Nigeria: --:--:--\nCameroon: --:--:--", 20f, white, true)
        box.addView(clockText)

        box.addView(tv("SIGNAL TIME (Nigeria time)", 14f, muted, true))
        timeInput = EditText(this).apply {
            hint = "HH:MM:SS"
            setTextColor(white)
            setHintTextColor(muted)
            textSize = 22f
            inputType = InputType.TYPE_CLASS_DATETIME
            setSingleLine(true)
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(21,27,23))
        }
        box.addView(timeInput, LinearLayout.LayoutParams(-1, 65))

        box.addView(tv("⏱️ WAIT SECONDS (1–60)", 14f, muted, true))
        secondsInput = EditText(this).apply {
            hint = "10"
            setText("10")
            setTextColor(white)
            setHintTextColor(muted)
            textSize = 22f
            inputType = InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(21,27,23))
        }
        box.addView(secondsInput, LinearLayout.LayoutParams(-1, 65))

        countdownText = tv("Ready.", 30f, green, true)
        countdownText.gravity = Gravity.CENTER
        box.addView(countdownText)

        val start = Button(this).apply {
            text = "⏰ START 10-SECOND TIMER"
            textSize = 16f
            setOnClickListener { scheduleSignal() }
        }
        box.addView(start, LinearLayout.LayoutParams(-1, 62))

        val test = Button(this).apply {
            text = "🧪 TEST ALERT NOW"
            textSize = 16f
            setOnClickListener { SignalReceiver.fire(this@MainActivity, true) }
        }
        box.addView(test, LinearLayout.LayoutParams(-1, 62))

        val cancel = Button(this).apply {
            text = "✖ CANCEL TIMER"
            textSize = 15f
            setOnClickListener {
                SignalReceiver.cancel(this@MainActivity)
                prefs.edit().remove("target").apply()
                statusText.text = "Timer cancelled."
                countdownText.text = "Ready."
            }
        }
        box.addView(cancel, LinearLayout.LayoutParams(-1, 58))

        statusText = tv("Tip: allow notifications when Android asks.", 14f, muted)
        box.addView(statusText)

        box.addView(tv("🔊 Alert voice:", 15f, muted, true))
        box.addView(tv("“O boy! Place bet now ooh! Place bet now! No dulling!” 😂", 15f, white))

        scroll.addView(box)
        setContentView(scroll)
    }

    private fun scheduleSignal() {
        val raw = timeInput.text.toString().trim()
        val parts = raw.split(":")
        if (parts.size != 3) {
            timeInput.error = "Use HH:MM:SS"
            return
        }
        val h = parts[0].toIntOrNull()
        val m = parts[1].toIntOrNull()
        val s = parts[2].toIntOrNull()
        if (h == null || m == null || s == null || h !in 0..23 || m !in 0..59 || s !in 0..59) {
            timeInput.error = "Invalid time"
            return
        }

        val now = ZonedDateTime.now(zone)
        var target = now.withHour(h).withMinute(m).withSecond(s).withNano(0)
        if (!target.isAfter(now)) target = target.plusDays(1)

        val waitSeconds = secondsInput.text.toString().toLongOrNull()
        if (waitSeconds == null || waitSeconds !in 1..60) {
            secondsInput.error = "Enter 1 to 60 seconds"
            return
        }

        // The signal time is the point at which the countdown begins.
        // The alert fires after the user-selected number of seconds.
        val alert = target.plusSeconds(waitSeconds)
        prefs.edit().putLong("target", alert.toInstant().toEpochMilli()).apply()
        SignalReceiver.schedule(this, alert.toInstant().toEpochMilli())

        statusText.text = "Scheduled: ${target.format(DateTimeFormatter.ofPattern("HH:mm:ss"))} → alert ${waitSeconds}s later."
        startCountdown(alert.toInstant().toEpochMilli())
    }

    private fun startCountdown(targetMs: Long) {
        handler.post(object : Runnable {
            override fun run() {
                val remaining = targetMs - System.currentTimeMillis()
                if (remaining <= 0) {
                    countdownText.text = "🔔 ALERT!"
                    return
                }
                val sec = remaining / 1000
                val ms = remaining % 1000
                countdownText.text = "⏳ ${sec}s"
                handler.postDelayed(this, 200)
            }
        })
    }

    private fun tick() {
        val now = ZonedDateTime.now(zone)
        val fmt = DateTimeFormatter.ofPattern("HH:mm:ss")
        clockText.text = "Nigeria 🇳🇬: ${now.format(fmt)}\nCameroon 🇨🇲: ${now.format(fmt)}"
        handler.postDelayed({ tick() }, 1000)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
