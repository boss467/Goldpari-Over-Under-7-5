package com.goldpari.overunder75

import android.app.*
import android.content.Context
import android.os.Build

object NotificationHelper {
    private const val CHANNEL = "goldpari_alerts"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val c = NotificationChannel(
                CHANNEL,
                "Goldpari timer alerts",
                NotificationManager.IMPORTANCE_HIGH
            )
            c.description = "10-second timer alerts"
            c.enableVibration(true)
            nm.createNotificationChannel(c)
        }
    }

    fun notify(context: Context, message: String) {
        createChannel(context)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val builder = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(context, CHANNEL)
        else
            Notification.Builder(context)

        val n = builder
            .setSmallIcon(com.goldpari.overunder75.R.drawable.ic_launcher)
            .setContentTitle("Goldpari Over & Under 7.5")
            .setContentText(message)
            .setStyle(Notification.BigTextStyle().bigText(message))
            .setAutoCancel(true)
            .setPriority(Notification.PRIORITY_HIGH)
            .build()

        if (Build.VERSION.SDK_INT < 33 ||
            context.checkSelfPermission("android.permission.POST_NOTIFICATIONS") ==
            android.content.pm.PackageManager.PERMISSION_GRANTED) {
            nm.notify(7505, n)
        }
    }
}
