plugins {
    id("com.android.application")
}

android {
    namespace = "com.goldpari.overunder75"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.goldpari.overunder75"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
}
